<header id="print-header">
	<div class="fas fa-handshake"></div>
	<div id="coop-info">
		<h1><?php echo COOPERATIVE; ?></h1>
		<address>
			<?php echo BARANGAY."<br />".TOWN.", ".PROVINCE; ?><br />
			<?php echo LANDLINE." &#183; ".CP_NUMBER; ?>
		</address>
	</div>
</header><!-- #print-header -->
<hr class="print-hr" />