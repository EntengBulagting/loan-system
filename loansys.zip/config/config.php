<?php
// Location Parameters
define("COOPERATIVE", "Ciudad Nuevo Cooperative");
define("SUBDIVISION", "Ciudad Nuevo");
define("BARANGAY", "Timalan Balsahan");
define("TOWN", "Naic");
define("PROVINCE", "Cavite");
define("LANDLINE", "(046) 404-1739");
define("CP_NUMBER", "0907 489 5893");

// Database parameters
define("DB_HOST", "localhost");
define("DB_NAME", "cooperative");
define("DB_CHARSET", "UTF8");
define("DB_USER", "theresa_de_ocampo");
define("DB_PASSWORD", "mtdo_bsit");